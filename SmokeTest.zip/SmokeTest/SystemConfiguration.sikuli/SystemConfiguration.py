#System Configuration
#Smoke Test the System Configuration
#Create a text file with the name and location as indicated below.
t=3
log_dir = "C:\\sikuli\\logs\\"
el = "\n"                    #the end of line you want to use
my_file=file(log_dir+"SysConfig.txt","w") 
my_file.write("System Configuration Smoke Test" +el) #Add text to file

click("SysConfButton.png")
wait(10)

#Select User

click(Pattern("users.png").similar(0.85).targetOffset(-33,7))
click(Pattern("testuser1.png").similar(0.94).targetOffset(2,-18))
click(Pattern("Operator.png").similar(0.84).targetOffset(-53,-1))
click(Pattern("savebut.png").similar(0.85).targetOffset(-42,1))
click(Pattern("dynacuser.png").similar(0.87).targetOffset(4,2))
click(Pattern("testuser1.png").similar(0.94).targetOffset(2,-17))
if exists(Pattern("SelOper.png").similar(0.90)):
    my_file.write("Select Operator Role Successful"+el)  #Write to file
else:
    my_file.write("Select Operator Role Unsuccessful"+el)  #Write to file

#Delete User

click (Pattern("greg8.png").similar(0.85).targetOffset(6,2))
click (Pattern("DeleteButton.png").similar(0.91).targetOffset(28,1))
click (Pattern("DeleteUser.png").similar(0.85).targetOffset(42,48))
if exists("1488399533925.png"):
    my_file.write("Delete User Successful"+el)  #Write to file
else:
    my_file.write("Delete User Unsuccessful"+el)  #Write to file

#See Workstations

click(Pattern("Workstations.png").similar(0.85).targetOffset(-80,-12))
click(Pattern("winWS1.png").similar(0.91).targetOffset(-1,-20))
if exists("1488401519642.png"):
    my_file.write("Good IPAddress"+el)
else:
    my_file.write("Bad IPAddress"+el)
    
rightClick("SysConfTab.png")
click(Pattern("Close.png").similar(0.80).targetOffset(-90,-41))
my_file.close