#Registry Browser
#Smoke Test the Registry Browser
#Create a text file with the name and location as indicated below.
t=3
log_dir = "C:\\sikuli\\logs\\"
el = "\n"                    #the end of line you want to use
my_file=file(log_dir+"RegBrowser.txt","w")        

click(Pattern("RegBrowser.png").similar(0.90))
wait(t)
click("1488472176408.png")
click(Pattern("pagefor.png").similar(0.85).targetOffset(-30,0))
click(Pattern("TSTANA1.png").exact().targetOffset(-6,-5))
click(Pattern("Value.png").similar(0.85).targetOffset(14,28))
type('a',KEY_CTRL)  # clear textfield
type('15')       # enter information in textfield
wait(t)
#Click on the Tabs
my_file.write("Registry Browser Smoke Test" +el)
my_file.write("COMMANDS"+el)

click(Pattern("CommTab.png").similar(0.85).targetOffset(-4,2))
if exists("1488472414219.png"):
    my_file.write("good commands tab"+el)
wait(t)
my_file.write("STATUS"+el)
click(Pattern("status.png").similar(0.80))
if exists("1488472448498.png"):
    my_file.write("good status tab"+el)
wait(t)
my_file.write("TAGS"+el)
click("1488472465291.png")
if exists("1488472489921.png"):
    my_file.write("good Tags tab"+el)
wait(t)
my_file.write("SCRIPT"+el)
click("1488472512728.png")
if exists("1488472533369.png"):
    my_file.write("good Script tab"+el)
wait(t)
my_file.write("SIMULATION SCRIPT"+el)
click("1488472562219.png")
if exists("1488472583560.png"):
    my_file.write("good Simulation Script tab"+el)
wait(t)
my_file.write("ALARMS"+el)
click("1488472610915.png")
if exists("1488472631698.png"):
    my_file.write("good Alarms tab"+el)
wait(t)
my_file.write("ASPECTS"+el)
click("1488472661326.png")
if exists("1488472681342.png"):
    my_file.write("good Aspects tab"+el)
wait(t)
my_file.write("NOTES"+el)
click("1488472698270.png")
if exists("1488472721695.png"):
    my_file.write("good Notes tab"+el)

#Click on different points
my_file.write("SELECT TSTDIG"+el)
click(Pattern("TSTDig1.png").similar(0.85))
if exists("1488472800514.png"):
    my_file.write("TSTDIG"+el)
my_file.write("SELECT ADAPTERS"+el)
click("1488472826507.png")
click("1488472862125.png")
if exists("1488472890310.png"):
    my_file.write("adapters/D095N_01"+el)
    
rightClick("1488383312640.png")
click(Pattern("Close.png").similar(0.80).targetOffset(-90,-41))
my_file.close