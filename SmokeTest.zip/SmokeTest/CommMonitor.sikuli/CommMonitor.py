#Communication Monitor
#Smoke Test the Communication Monitor
#Create a text file with the name and location as indicated below.

import shutil
import os

t=3
log_dir = "C:\\sikuli\\logs\\"
pic_dir = "C:\\sikuli\\logs\\Log_pic\\"
el = "\n"                    #the end of line you want to use
my_file=file(log_dir+"CommMon.txt","w") 
my_file.write("Commmunication Monitor Smoke Test" +el) #Add text to file

click(Pattern("CommBut.png").similar(0.95))
wait(15)
click(Pattern("CommMonSelect.png").similar(0.85).targetOffset(-85,-3))
click(Pattern("Channels.png").similar(0.85).targetOffset(-56,-11))
click(Pattern("controllers.png").similar(0.85).targetOffset(-51,8))
click(Pattern("sign.png").similar(0.85).targetOffset(20,18))
wait(2)
img = capture(SCREEN)
shutil.move(img,os.path.join(pic_dir,"SignDevice.png"))
if exists("1488461749476.png"):
    my_file.write("Sign Status showing"+el)
    my_file.write(pic_dir+"SignDevice.png"+el)
    
else:
    my_file.write("No Sign Device showing"+el)

click(Pattern("controllerpic.png").similar(0.85).targetOffset(-16,5))
wait(2)

img = capture(SCREEN)
shutil.move(img,os.path.join(pic_dir,"SignController.png"))
if exists("1488461295055.png"):
    my_file.write("Sign Controller Status showing"+el)
    my_file.write(pic_dir+"SignController.png"+el) 
else:
    my_file.write("No Sign Controller showing"+el)

click(Pattern("chanSign.png").similar(0.85).targetOffset(-30,10))
wait(2)

img = capture(SCREEN)
shutil.move(img,os.path.join(pic_dir,"SignChannel.png"))
if exists("1488470644421.png"):
    my_file.write("Sign Channel Status showing"+el)
    my_file.write(pic_dir+"SignChannel.png"+el) 
else:
    my_file.write("No Sign Channel showing"+el)

click(Pattern("ScanGroup.png").similar(0.85).targetOffset(-58,0))
wait(2)

img = capture(SCREEN)
shutil.move(img,os.path.join(pic_dir,"ScanGroup.png"))
if exists("1488470824059.png"):
    my_file.write("Sign Channel Status showing"+el)
    my_file.write(pic_dir+"ScanGroup.png"+el) 
else:
    my_file.write("No Sign Channel showing"+el)

rightClick("CommMonTab.png")
click(Pattern("Close.png").similar(0.80).targetOffset(-90,-41))
my_file.close