#IRM from GIS
#Smoke Test the Incident from GIS
#Create a text file with the name and location as indicated below.

import shutil
import os

def myHandler(event):
    evetn.region.stopObserver()   #stops the observation
t=3
log_dir = "C:\\sikuli\\logs\\"
pic_dir = "C:\\sikuli\\logs\\Log_pic\\"
el = "\n"                    #the end of line you want to use
my_file=file(log_dir+"IRM.txt","w") 
my_file.write("Incident GIS Smoke Test" +el) #Add text to file

#Create an Incident
rightClick(Pattern("MapXMS1.png").similar(0.85).targetOffset(-3,-81))
click(Pattern("CreateInc.png").similar(0.85).targetOffset(-29,-9))
onAppear("1488480168926.png",myHandler)
click(Pattern("LaneBlock.png").similar(0.85).targetOffset(-50,11))
click(Pattern("PlansSelect.png").similar(0.85).targetOffset(-25,-4))
click(Pattern("searchbut.png").similar(0.85))
click(Pattern("choosePlan.png").similar(0.85).targetOffset(-119,0))
click(Pattern("CreateBut.png").similar(0.85).targetOffset(-64,1))
wait(10)
if exists("1488481021574.png"):
    click(Pattern("closebut.png").similar(0.85).targetOffset(-31,1))
    if exists("1488481153021.png"):
        my_file.write("Incident was created" +el) #Add text to file
    else:
        my_file.write("Incident was not created on GIS map"+el)
else:
    my_file.write("Incident was not created"+el)

# Terminate Incident
doubleClick(Pattern("reopenInc.png").similar(0.90).targetOffset(2,-73))
wait(5)
click(Pattern("TerminateInc.png").similar(0.85))
click(Pattern("IncTerm.png").similar(0.85).targetOffset(62,43))
click(Pattern("DynacMess.png").similar(0.85).targetOffset(254,46))
my_file.write("Incident deleted"+el)
my_file.close